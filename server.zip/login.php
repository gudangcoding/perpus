<?php
include"koneksi.php";
$post = json_decode(file_get_contents('php://input'), true);
//cek ketabel member apakah ada member_id dan password seperti yang dikirimkan
  $password = $post['mpasswd'];
  $query = $conn->query("SELECT * FROM member WHERE member_id='$post[member_id]' AND mpasswd='$password'");
  $jml = mysqli_num_rows($query);
  if($jml>0){  
    $data = mysqli_fetch_array($query);
    $photo = file_get_contents($data['photo']);
    $datamember = array(
      'member_id' => $data['member_id'],
      'member_name' => $data['member_name'],
      'member_email' => $data['member_email'],
      'mpasswd' => $data['mpasswd'],
      'foto' => base64_encode($photo)
    );
    
    if($query) $result = json_encode(array('success'=>true, 'result'=>$datamember));
    else $result = json_encode(array('success'=>false, 'msg'=>'Login gagal'));
  }else{
      $result = json_encode(array('success'=>false, 'msg'=>'Akun tidak terdaftar'));
  }
  echo $result;
?>