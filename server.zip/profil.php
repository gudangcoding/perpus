<?php
include"koneksi.php";
$post = json_decode(file_get_contents('php://input'), true);
$member = $post['member'];
$sql = "SELECT
*
FROM
member
WHERE
member.member_id='$member'";

$query = $conn->query($sql);
$data = array();
foreach($query as $row)
{
	$data[] = $row;
}
if($query)$result = json_encode(array("success"=>true,'result'=>$data));
else $result = json_encode(array("success"=>false));
echo $result;
?>