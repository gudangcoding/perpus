<?php
include"koneksi.php";
$post = json_decode(file_get_contents('php://input'), true);
$start = $post['start'];
$limit = $post['limit'];
$query = $conn->query("SELECT * FROM biblio limit 0 ,5");
//$data = array();
foreach($query as $row)
{
	$data[] = array(
		'title'=>$row['title'],
		'image'=>'images/buku/'.$row['image'],
		
	);
}
$result = json_encode(array("success"=>true,'result'=>$data));
echo $result;
?>