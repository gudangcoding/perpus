<?php
include"koneksi.php";
$post = json_decode(file_get_contents('php://input'), true);
$member = $post['member'];
$sql = "SELECT
loan.loan_id,
loan.item_code,
biblio.title,
member.member_name,
biblio.biblio_id,
member.member_id,
loan.loan_date,
loan.due_date
FROM
loan,member,biblio
WHERE
loan.member_id=member.member_id AND loan.item_code=biblio.biblio_id AND member.member_id='$member'";

$query = $conn->query($sql);
$data = array();
foreach($query as $row)
{
	$data[] = array(
		'title'=>$row['title'],
		'image'=>'images/buku/'.$row['image'],
	);
}
if($query)$result = json_encode(array("success"=>true,'result'=>$data));
else $result = json_encode(array("success"=>false));
echo $result;
?>