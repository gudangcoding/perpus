-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 26, 2019 at 03:52 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id10593087_mastervoting`
--

-- --------------------------------------------------------

--
-- Table structure for table `biblio`
--

CREATE TABLE `biblio` (
  `biblio_id` int(11) NOT NULL,
  `gmd_id` int(3) DEFAULT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `sor` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `edition` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isbn_issn` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publisher_id` int(11) DEFAULT NULL,
  `publish_year` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `collation` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `series_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `call_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_id` char(5) COLLATE utf8_unicode_ci DEFAULT 'en',
  `source` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publish_place_id` int(11) DEFAULT NULL,
  `classification` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_att` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `opac_hide` smallint(1) DEFAULT 0,
  `promoted` smallint(1) DEFAULT 0,
  `labels` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequency_id` int(11) NOT NULL DEFAULT 0,
  `spec_detail_info` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `media_type_id` int(11) DEFAULT NULL,
  `carrier_type_id` int(11) DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `uid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `biblio`
--

INSERT INTO `biblio` (`biblio_id`, `gmd_id`, `title`, `sor`, `edition`, `isbn_issn`, `publisher_id`, `publish_year`, `collation`, `series_title`, `call_number`, `language_id`, `source`, `publish_place_id`, `classification`, `notes`, `image`, `file_att`, `opac_hide`, `promoted`, `labels`, `frequency_id`, `spec_detail_info`, `content_type_id`, `media_type_id`, `carrier_type_id`, `input_date`, `last_update`, `uid`) VALUES
(1, 1, 'PHP 5 for dummies', NULL, NULL, '0764541668', 1, '2004', 'xiv, 392 p. : ill. ; 24 cm.', 'For dummies', '005.13/3-22 Jan p', 'en', NULL, 1, '005.13/3 22', NULL, 'buku1.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 15:36:50', '2007-11-29 16:26:59', NULL),
(2, 1, 'Linux In a Nutshell', NULL, 'Fifth Edition', '9780596009304', 2, '2005', 'xiv, 925 p. : ill. ; 23 cm.', 'In a Nutshell', '005.4/32-22 Ell l', 'en', NULL, 2, '005.4/32 22', NULL, 'buku2.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 15:53:35', '2007-11-29 16:26:10', NULL),
(3, 1, 'The Definitive Guide to MySQL 5', NULL, NULL, '9781590595350', 3, '2005', '784p.', 'Definitive Guide Series', '005.75/85-22 Kof d', 'en', NULL, NULL, '005.75/85 22', NULL, 'buku3.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 16:01:08', '2007-11-29 16:26:33', NULL),
(4, 1, 'Cathedral and the Bazaar: Musings on Linux and Open Source by an Accidental Revolutionary', NULL, NULL, '0-596-00108-8', 2, '2001', '208p.', NULL, '005.4/3222 Ray c', 'en', NULL, 2, '005.4/32 22', 'The Cathedral & the Bazaar is a must for anyone who cares about the future of the computer industry or the dynamics of the information economy. This revised and expanded paperback edition includes new material on open source developments in 1999 and 2000. Raymond\'s clear and effective writing style accurately describing the benefits of open source software has been key to its success. (Source: http://safari.oreilly.com/0596001088)', 'buku4.jpg', 'cathedral-bazaar.pdf', 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 16:14:44', '2007-11-29 16:25:43', NULL),
(5, 1, 'Producing open source software : how to run a successful free software project', NULL, '1st ed.', '9780596007591', 2, '2005', 'xx, 279 p. ; 24 cm.', NULL, '005.1-22 Fog p', 'en', NULL, 2, '005.1 22', 'Includes index.', 'buku5.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 16:20:45', '2007-11-29 16:31:21', NULL),
(6, 1, 'PostgreSQL : a comprehensive guide to building, programming, and administering PostgreSQL databases', NULL, '1st ed.', '0735712573', 4, '2003', 'xvii, 790 p. : ill. ; 23cm.', 'DeveloperÃ¢â‚¬â„¢s library', '005.75/85-22 Kor p', 'en', NULL, 3, '005.75/85 22', 'PostgreSQL is the world\'s most advanced open-source database. PostgreSQL is the most comprehensive, in-depth, and easy-to-read guide to this award-winning database. This book starts with a thorough overview of SQL, a description of all PostgreSQL data types, and a complete explanation of PostgreSQL commands.', 'buku1.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 16:29:33', '2019-05-14 07:39:21', NULL),
(7, 1, 'Web application architecture : principles, protocols, and practices', NULL, NULL, '0471486566', 5, '2003', 'xi, 357 p. : ill. ; 23 cm.', NULL, '005.7/2-21 Leo w', 'en', NULL, 1, '005.7/2 21', 'An in-depth examination of the core concepts and general principles of Web application development.\r\nThis book uses examples from specific technologies (e.g., servlet API or XSL), without promoting or endorsing particular platforms or APIs. Such knowledge is critical when designing and debugging complex systems. This conceptual understanding makes it easier to learn new APIs that arise in the rapidly changing Internet environment.', 'buku2.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 16:41:57', '2007-11-29 16:32:46', NULL),
(8, 1, 'Ajax : creating Web pages with asynchronous JavaScript and XML', NULL, NULL, '9780132272674', 6, '2007', 'xxii, 384 p. : ill. ; 24 cm.', 'Bruce PerensÃ¢â‚¬â„¢ Open Source series', '006.7/86-22 Woy a', 'en', NULL, 4, '006.7/86 22', 'Using Ajax, you can build Web applications with the sophistication and usability of traditional desktop applications and you can do it using standards and open source software. Now, for the first time, there\'s an easy, example-driven guide to Ajax for every Web and open source developer, regardless of experience.', 'buku3.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 16:47:20', '2019-05-14 07:39:21', NULL),
(9, 1, 'The organization of information', NULL, '2nd ed.', '1563089769', 7, '2004', 'xxvii, 417 p. : ill. ; 27 cm.', 'Library and information science text series', '025-22 Tay o', 'en', NULL, 5, '025 22', 'A basic textbook for students of library and information studies, and a guide for practicing school library media specialists. Describes the impact of global forces and the school district on the development and operation of a media center, the technical and human side of management, programmatic activities, supportive services to students, and the quality and quantity of resources available to support programs.', 'buku4.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 16:54:12', '2007-11-29 16:27:20', NULL),
(10, 1, 'Library and Information Center Management', NULL, '7th ed.', '9781591584063', 7, '2007', 'xxviii, 492 p. : ill. ; 27 cm.', 'Library and information science text series', '025.1-22 Stu l', 'en', NULL, 5, '025.1 22', NULL, 'buku5.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 16:58:51', '2007-11-29 16:27:40', NULL),
(11, 1, 'Information Architecture for the World Wide Web: Designing Large-Scale Web Sites', NULL, '2nd ed.', '9780596000356', 2, '2002', '500p.', NULL, '006.7-22 Mor i', 'en', NULL, 6, '006.7 22', 'Information Architecture for the World Wide Web is about applying the principles of architecture and library science to web site design. Each website is like a public building, available for tourists and regulars alike to breeze through at their leisure. The job of the architect is to set up the framework for the site to make it comfortable and inviting for people to visit, relax in, and perhaps even return to someday.', 'buku1.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 17:26:14', '2007-11-29 16:32:25', NULL),
(12, 1, 'Corruption and development', NULL, NULL, '9780714649023', 8, '1998', '166 p. : ill. ; 22 cm.', NULL, '364.1 Rob c', 'en', NULL, 7, '364.1/322/091724 21', 'The articles assembled in this volume offer a fresh approach to analysing the problem of corruption in developing countries and the k means to tackle the phenomenon.', 'buku2.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 17:45:30', '2007-11-29 16:20:53', NULL),
(13, 1, 'Corruption and development : the anti-corruption campaigns', NULL, NULL, '0230525504', 9, '2007', '310p.', NULL, '364.1 Bra c', 'en', NULL, 8, '364.1/323091724 22', 'This book provides a multidisciplinary interrogation of the global anti-corruption campaigns of the last ten years, arguing that while some positive change is observable, the period is also replete with perverse consequences and unintended outcomes', 'buku3.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 17:49:49', '2007-11-29 16:19:48', NULL),
(14, 1, 'Pigs at the trough : how corporate greed and political corruption are undermining America', NULL, NULL, '1400047714', 10, '2003', '275 p. ; 22 cm.', NULL, '364.1323 Huf p', 'en', NULL, 8, '364.1323', NULL, 'buku4.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 17:56:00', '2007-11-29 16:18:33', NULL),
(15, 1, 'Lords of poverty : the power, prestige, and corruption of the international aid business', NULL, NULL, '9780871134691', 11, '1994', 'xvi, 234 p. ; 22 cm.', NULL, '338.9 Han l', 'en', NULL, 8, '338.9/1/091724 20', 'Lords of Poverty is a case study in betrayals of a public trust. The shortcomings of aid are numerous, and serious enough to raise questions about the viability of the practice at its most fundamental levels. Hancocks report is thorough, deeply shocking, and certain to cause critical reevaluation of the governments motives in giving foreign aid, and of the true needs of our intended beneficiaries.', 'buku5.jpg', NULL, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, '2007-11-29 18:08:13', '2007-11-29 16:13:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL,
  `item_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_id` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `loan_date` date NOT NULL,
  `due_date` date NOT NULL,
  `renewed` int(11) NOT NULL DEFAULT 0,
  `loan_rules_id` int(11) NOT NULL DEFAULT 0,
  `actual` date DEFAULT NULL,
  `is_lent` int(11) NOT NULL DEFAULT 0,
  `is_return` int(11) NOT NULL DEFAULT 0,
  `return_date` date DEFAULT NULL,
  `input_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `uid` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loan_id`, `item_code`, `member_id`, `loan_date`, `due_date`, `renewed`, `loan_rules_id`, `actual`, `is_lent`, `is_return`, `return_date`, `input_date`, `last_update`, `uid`) VALUES
(1, '1', 'J91218101', '2019-08-22', '2019-08-29', 0, 0, NULL, 0, 0, NULL, NULL, NULL, NULL),
(2, '2', 'J91218101', '2019-08-22', '2019-08-29', 0, 0, NULL, 0, 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `member_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `member_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `gender` int(1) NOT NULL,
  `birth_date` date DEFAULT NULL,
  `member_type_id` int(6) DEFAULT NULL,
  `member_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_mail_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inst_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_new` int(1) DEFAULT NULL,
  `member_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pin` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_phone` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_fax` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `member_since_date` date DEFAULT NULL,
  `register_date` date DEFAULT NULL,
  `expire_date` date NOT NULL,
  `member_notes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_pending` smallint(1) NOT NULL DEFAULT 0,
  `mpasswd` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_login_ip` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `input_date` date DEFAULT NULL,
  `last_update` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `member_name`, `gender`, `birth_date`, `member_type_id`, `member_address`, `member_mail_address`, `member_email`, `postal_code`, `inst_name`, `is_new`, `member_image`, `pin`, `member_phone`, `member_fax`, `member_since_date`, `register_date`, `expire_date`, `member_notes`, `is_pending`, `mpasswd`, `last_login`, `last_login_ip`, `input_date`, `last_update`) VALUES
('J91218101', 'ARINA MUSTAFIDAH', 0, '1996-08-19', 2, 'LAJO LOR-SINGGAHAN-TUBAN', NULL, 'arinamustafidah19@gmail.com', '62361', '1', 0, NULL, NULL, '85731632325', NULL, '2014-09-05', '2014-09-05', '2020-12-31', NULL, 0, '123456', NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218120', 'YUSRIL IHZA', 0, '0000-00-00', 2, 'JALAN PEGANDEN INDAH IV RT 14 RW 03   Kab. Gresik   Jawa Timur 61151', NULL, NULL, NULL, '26', 0, NULL, NULL, '85785154283', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218119', 'YUDIS RIZQI ALIFFIAN', 1, NULL, 2, 'BANPRES TNI AL BLOK K NO.9 RT/RW: 02/028 DESA. CIANGSANA KEC. GUNUNG PUTRI Kab. Bogor   Jawa Barat 16968', NULL, NULL, NULL, '26', 0, NULL, NULL, '89634643680', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218118', 'VELY OLY WIDYA PUTRI', 0, NULL, 2, 'JLN.PUNDEN NO.65 GG.03 RT.01 RW.01 WAGE TAMAN,SIDOARJO Kab. Sidoarjo   Jawa Timur 61257', NULL, NULL, NULL, '26', 0, NULL, NULL, '81553628985', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218117', 'VALERIAN', 1, '0000-00-00', 2, 'JL. BOHAR TIMUR RT 11 RW 06 TMAN SIDOARJO Kab. Sidoarjo   Jawa Timur 61257', NULL, NULL, NULL, '26', 0, NULL, NULL, '85334791205', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218116', 'TSAFITRI RINTI TADDAGA', 0, NULL, 2, 'DS. DRAJAT-KEC. PACIRAN-KAB. LAMONGAN RT. 2RW. 2 Kab. Lamongan   Jawa Timur 62264', NULL, NULL, NULL, '26', 0, NULL, NULL, '82132236441', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218115', 'TAZKIA SYAFA ZALZABILA', 0, NULL, 2, 'TROSOBO RT 02 RW 07 TAMAN   Kab. Sidoarjo   Jawa Timur 61257', NULL, NULL, NULL, '26', 0, NULL, NULL, '895339000000', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218114', 'SOFIA NUR HIDAYAH', 0, NULL, 2, 'DUSUN SARIREJO 1 RT 16/ RW 03 DESA KEBONSARI KECAMATAN SUMBERSUKO Kab. Lumajang   Jawa Timur 67316', NULL, NULL, NULL, '26', 0, NULL, NULL, '85257393716', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218113', 'SHOFIYYAH', 0, NULL, 2, 'JL AMPEL KEMBANG NO 40 SURABAYA   Kota Surabaya   Jawa Timur 60151', NULL, NULL, NULL, '26', 0, NULL, NULL, '83830828729', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218112', 'RR. LOKANINDISWARI IMANTIARA AYU SARASTANTI', 0, NULL, 2, 'WONOKITRI 2/73   Kota Surabaya   Jawa Timur 60256', NULL, NULL, NULL, '26', 0, NULL, NULL, '81232768505', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218111', 'RIA FITRIA NINGSIH', 0, NULL, 2, 'JL.MARGOMULYO GG 1/19 DUKUH SENTONG   Kota Surabaya   Jawa Timur 60186', NULL, NULL, NULL, '26', 0, NULL, NULL, '81217012659', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218110', 'REGITA HAYUPAKSI', 0, NULL, 2, 'TEMBOK DUKUH GANG V NO 50   Kota Surabaya   Jawa Timur 60173', NULL, NULL, NULL, '26', 0, NULL, NULL, '8995357937', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218109', 'REGINA ADILIA WIDYA', 0, NULL, 2, 'JL. MERAK TK BLOQ Q II NO. 124 REWWIN   Kab. Sidoarjo   Jawa Timur 61256', NULL, NULL, NULL, '26', 0, NULL, NULL, '8123281845', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218108', 'QUROTUL AINAYAH', 0, NULL, 2, 'PARENGAN MADURAN LAMONGAN   Kab. Lamongan   Jawa Timur 62261', NULL, NULL, NULL, '26', 0, NULL, NULL, '81331248381', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218107', 'PRASETYA EKO NUGROHO', 1, NULL, 2, 'JL DUKUH MENANGGAL 5A/6C GAYUNGAN SURABAYA Kota Surabaya   Jawa Timur 60234', NULL, NULL, NULL, '26', 0, NULL, NULL, '895401000000', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218106', 'NUR HAMIDAH', 0, NULL, 2, 'JL.KH. ABDULLAH SAJAD RT. 24 RW. 09 DESA KEDUNGMALING KECAMATAN SOOKO Kab. Mojokerto   Jawa Timur 61361', NULL, NULL, NULL, '26', 0, NULL, NULL, '8383745088', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218105', 'NIKEN VIRDAYANTI', 0, NULL, 2, 'JALAN MEDOKAN SEMAMPIR INDAH NOMOR 66   Kota Surabaya   Jawa Timur 60119', NULL, NULL, NULL, '26', 0, NULL, NULL, '85854457566', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218104', 'NABIL AMIROH BILQIS', 0, NULL, 2, 'KRAJAN RT 16 RW 03 KARANGSARI BANTUR   Kota Malang   Jawa Timur 65179', NULL, NULL, NULL, '26', 0, NULL, NULL, '81252682565', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218103', 'MUSYRIFATUL HIDAYAH', 0, NULL, 2, 'DSN MENYANGGONG, RT:24, RW:10 KLETEK, TAMAN Kab. Sidoarjo   Jawa Timur 61257', NULL, NULL, NULL, '26', 0, NULL, NULL, '89620453083', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14'),
('J91218102', 'MUHAMMAD YUSRON ALFATTA', 1, NULL, 2, 'DSN I SEI KANDIS 002/001 SEI KANDIS PENDALIAN IV KOTO ROKAN HULU RIAU Kab. Rokan Hulu   Riau 28557', NULL, NULL, NULL, '26', 0, NULL, NULL, '82284534025', NULL, '2018-09-04', '2018-09-04', '2019-09-04', NULL, 0, NULL, NULL, NULL, '2019-05-14', '2019-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kandidat`
--

CREATE TABLE `tbl_kandidat` (
  `id_kandidat` int(11) NOT NULL,
  `presma` varchar(50) NOT NULL,
  `wapresma` varchar(50) NOT NULL,
  `visi` varchar(300) NOT NULL,
  `misi` text NOT NULL,
  `foto` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kandidat`
--

INSERT INTO `tbl_kandidat` (`id_kandidat`, `presma`, `wapresma`, `visi`, `misi`, `foto`) VALUES
(7, 'AYIK DHIAN WINARNI', 'DWEY ROBBY HENDRAWAN', 'Membangun Negeri dengan Baik', '<p>Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Pellentesque in ipsum id orci porta dapibus. Donec sollicitudin molestie malesuada. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Curabitur aliquet quam id dui posuere blandit. Cras ultricies ligula sed magna dictum porta. Sed porttitor lectus nibh. Donec rutrum congue leo eget malesuada.</p>', 'calon-1848-ayik-dhian-winarnidwey-robby-hendrawan.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `id_login` int(11) NOT NULL,
  `nis` varchar(35) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kelas` varchar(255) NOT NULL,
  `program` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id_login`, `nis`, `nama`, `kelas`, `program`, `password`, `level`) VALUES
(1, 'admin', 'Administrator', '', '', '2a24588d01f86c4822d68b5c383cb141', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_voting`
--

CREATE TABLE `tbl_voting` (
  `id_voting` int(11) NOT NULL,
  `id_kandidat` int(11) NOT NULL,
  `id_login` int(11) NOT NULL,
  `waktu` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_kandidat`
--
ALTER TABLE `tbl_kandidat`
  ADD PRIMARY KEY (`id_kandidat`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`id_login`);

--
-- Indexes for table `tbl_voting`
--
ALTER TABLE `tbl_voting`
  ADD PRIMARY KEY (`id_voting`),
  ADD KEY `id_kandidat` (`id_kandidat`,`id_login`),
  ADD KEY `id_login` (`id_login`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_kandidat`
--
ALTER TABLE `tbl_kandidat`
  MODIFY `id_kandidat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_voting`
--
ALTER TABLE `tbl_voting`
  MODIFY `id_voting` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_voting`
--
ALTER TABLE `tbl_voting`
  ADD CONSTRAINT `tbl_voting_ibfk_1` FOREIGN KEY (`id_kandidat`) REFERENCES `tbl_kandidat` (`id_kandidat`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_voting_ibfk_2` FOREIGN KEY (`id_login`) REFERENCES `tbl_login` (`id_login`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
